<div class="vcenter">
	<img src="../frontoffice/imagenes/logo.png" alt="Logo">
</div>
<div>
	<h1>BACK-OFFICE</h1>
</div>