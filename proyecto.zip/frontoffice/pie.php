<footer>
	<div>
		<p>
		¿Necesitas ayuda?<br>
		Localizar o gestionar compras<br>
		Tarifas y políticas de envío<br>
		Devolver o reemplazar productos<br>
		</p>
	</div>
	<div>
		<p>
		Métodos de pago TTOUNKYO<br>
		Métodos de pago<br>
		Conversor de divisas<br>
		Cheques Regalo<br>
		</p>
	</div>
	<div>
		<p>
		Avisos y condiciones<br>
		Condiciones de Uso y Venta<br>
		Aviso de privacidad<br>
		Área legalCookies y Publicidad
		en Internet<br>
		</p>
	</div>
	<span>
		© 1996-2015, ttounkyo.com, Inc. o afiliados. Todos los derechos reservados.
	
	<a href="facebook.com"><img class="redessociales" src="imagenes/face.png" alt="logo"></a>
	<a href="facebook.com"><img class="redessociales" src="imagenes/insta.png" alt="logo"></a>
	<a href="facebook.com"><img class="redessociales" src="imagenes/twitter.png" alt="logo"></a>
	</span>
</footer>