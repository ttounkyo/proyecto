<form class='usuario' action='../backoffice/altausuario' method='POST'>
	<h1>Alta de usuarios</h1>
	<div><label for="nomuser">Nombre de usuario: </label><br>	<input type='text' value='' name='username' /></div>
	<div><label for="nombre">Nombre: </label><br>	<input type='text' value='' name='nombre' /></div>
	<div><label for="apellido">Apellidos: </label><br>	<input type='text' value='' name='apellidos' /></div>
	<div><label for="email">eMAIL: </label><br>	<input type='text' value='' name='email' /></div>
	<div><label for="telefono">Telefono: </label><br>	<input type='text' value='' name='telefono' /></div>
	<div><label for="direccion">Direccion: </label><br>	<input type='text' value='' name='direccion' /></div>
	<!-- 	<div><label for="rol">Rol: </label><input type='text' value='' name='rol' /></div>
 -->	<div><label for="pass">Contraseña: </label><br>	<input type='password' name='passwd' /></div><br>	
	<div ><button class="btn" type='submit' name='enviar'>Enviar</button></div>
</form>