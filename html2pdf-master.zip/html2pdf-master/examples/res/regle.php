<style type="text/css">
<!--
    table
    {
        padding: 0;
        margin: 0;
        border: none;
        border-right: solid 0.2mm black;
    }
    td
    {
        padding: 0;
        margin: 0;
        border: none;
    }

    img
    {
        width: 10mm;
    }
-->
</style>
<page>
    <table cellpadding="0" cellspacing="0">
        <tr>
<?php
for ($k=0; $k<28;$k++) {
    echo '<td><img src="./res/regle.png" alt="" ><br>'.$k.'</td>';
}
?>
        </tr>
    </table>
</page>
